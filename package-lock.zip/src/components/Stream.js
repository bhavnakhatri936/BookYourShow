import React from 'react'

export default function Stream() {
  return (
    <div className='stream container'><img src={'/images/streamimg.avif'} alt="" /></div>
  )
}
