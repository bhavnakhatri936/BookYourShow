import React from "react";

export default function TvshowsDetail(props) {
    let { name, image, popularity } = props;
    return (
        <>
        <div className="tvDetDiv">
            <img src={`https://image.tmdb.org/t/p/w300` + image} alt="" />
            <div className="tv" style={{width: '250px'}}>
            <h3>{name}</h3>
            <div className="graph"> 
            <img src={'/images/graph.png'} alt="" />
            <h3>{`${popularity} K Views`}</h3>
            </div>
            <button type="button" class="btn btn-danger mt-2">Watch Now</button>
            </div>
            </div>
        </>
    );
}
