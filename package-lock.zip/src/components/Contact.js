import React from 'react'

export default function Contact() {
  return (
    <>
    <section class="contact-section">
                 <div class="container contact">
                     <div class="section-title contact-style">
                         <h2>CONTACT US</h2>
                        
                     </div>
                     <div class="row">
                         <div class="col-md-6">
                             <div class="contact-form">
                                 <form>
                                     <div class="form-group"> <input type="text" placeholder="Your Name" /></div>
                                     <div class="form-group"><input type="email" placeholder="Your Email" /></div>
                                     <div class="form-group"><input type="text" placeholder="Subject" /></div>
                                     <div class="form-group"><textarea name="address" rows="3"
                                             placeholder="Your Message"></textarea></div>
                                     <div class="form-group"><button class="btn button btn-danger">Submit Form</button></div>
                                 </form>
                             </div>
                         </div>
                         <div class="col-md-6">
                             <div class="contact-block">
                                 <div class="contact-details"><a href="#"><i class="fas fa-map-marker-alt"></i> 100
                                         Mainstreet
                                         Center,
                                         Sydney</a>
                                 </div>
                                 <div class="contact-details"><a href="#"><i class="fas fa-phone-alt"></i> (208) 333
                                         9696</a></div>
                                 <div class="contact-details"><a href="#"><i class="far fa-envelope"></i>
                                         contact@example.com</a></div>
                                 <div class="contact-details"><a href="#"><img
                                             src="images/logo.png" />Support.onehost.com</a>
                                 </div>
                             </div>
 
                         </div>
                     </div>
                 </div>
             </section>
     </>
  )
}
