import React from 'react'

export default function LatestTrailers() {
  return (
    <div>LatestTrailers</div>
  )
}
