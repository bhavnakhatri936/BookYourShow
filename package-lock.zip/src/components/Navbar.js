import React from "react";
import { Link } from "react-router-dom";

export default function Navbar(props) {
    return (
        <>
            <div className="container">
                <div id="header">
                    <h1 id="logo">
                        <img src={"/images/book-your-show-logo.png"} alt="" />
                    </h1>
                    <div className="social">
                        <span>FOLLOW US ON:</span>
                        <div class="social-icons">
                            <ul>
                                <li>
                                    <Link to="/">
                                        <i class="fab fa-facebook-f"></i>
                                    </Link>
                                </li>
                                <li>
                                    <Link to="/">
                                        <i class="fab fa-twitter"></i>
                                    </Link>
                                </li>
                                <li>
                                    <Link to="/">
                                        <i class="fab fa-google-plus-g"></i>
                                    </Link>
                                </li>
                                <li>
                                    <Link to="/">
                                        <i class="fab fa-skype"></i>
                                    </Link>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div id="navigation">
                        <ul>
                            <li>
                                <Link className="active" to="/">
                                    HOME
                                </Link>
                            </li>
                            <li>
                                <div class="dropdown">
                                    <Link to="movies" className="dropbtn">
                                        MOVIES
                                    </Link>
                                    <div class="dropdown-content">
                                        <Link to="movies/nowplaying">
                                            NOW PLAYING
                                        </Link>
                                        <Link to="movies/toprated">
                                            TOP RATED
                                        </Link>
                                        <Link to="movies/popular">POPULAR</Link>
                                        <Link to="movies/upcoming">
                                            UPCOMING
                                        </Link>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="dropdown">
                                    <Link to="tvshows" className="dropbtn">
                                        TV SHOWS
                                    </Link>
                                    <div class="dropdown-content">
                                        <Link to="tv/airingtoday">AIRING TODAY</Link>
                                        <Link to="tv/ontheair">ON THE AIR</Link>
                                        <Link to="tv/popular">POPULAR</Link>
                                        <Link to="tv/toprated">TOP RATED</Link>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <Link to="news">NEWS</Link>
                            </li>
                            <li>
                                <Link to="contact">CONTACT</Link>
                            </li>
                        </ul>
                    </div>
                    <div id="sub-navigation">
                        
                        
                        <div id="search">
                            <form action="/" method="get">
                                <input
                                    type="text"
                                    name="search field"
                                    value="Enter search here"
                                    id="search-field"
                                    className="blink search-field"
                                />
                                <input
                                    type="submit"
                                    value="Submit"
                                    className="search-button"
                                />
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
