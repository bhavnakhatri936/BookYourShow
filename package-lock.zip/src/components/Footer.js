import React from 'react'

export default function Footer() {
  return (
  <>
   <footer class="site-footer">
            <div class="container footer">
                <div class="footer-details">
                    <div class="footer-icons">
                        <ul>
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                            <li><a href="#"><i class="fab fa-skype"></i></a></li>
                        </ul>
                    </div>
                    <div class="footer-content">
                        <i class="far fa-copyright"></i>
                        Copyright-2014-BookYourShow by Bhavna Khatri
                    </div>
                </div>
            </div>
        </footer>
  </>
  )
}
