import React from 'react'
// import { useEffect } from 'react';
// import { useState } from 'react'


export default function MoviesDetail(props) {
    
    // console.log(">>>>>>>>>>>>>>>>>>>>props",props);
    // const [data,setData] =useState([]) 
    // useEffect(()=>{
    //     let det=async()=>{
    //         var moive=await axios.get("https://api.themoviedb.org/3/movie/now_playing?language=en-US&page=1")
    //         console.log(">>>>>>>>>>>>>>>moive",moive);
    //         setData(moive.data.results)
    //     }
    //     det()
    // })

  return (
    <div className='container'>
        <div className="row w-100">
            <div className="col-md-3"><img src="" alt="" /></div>
            <div className="col-md-4">
                
                <div className='title pl-5 my-2'><h1>{props.title}</h1>
                {/* {data.map((item)=>{
                    <>
                      <img src={item.backdrop_path}/>  
                      <h1>id:{item.id}</h1> 
                      <p>title:{item.title}</p>  
                      </>
                }
                        
                )
                    } */}
                
                </div>
                <div className="ratings d-flex">
                    <div className='star mx-4'>star</div>
                    <div className='points mx-4'>points</div>
                    <div className='votes mx-4'>Votes</div>
                </div>
                <div className="review d-flex justify-content-between my-2" style={{backgroundColor: 'black', padding: '10px'}}>
                    <div>
                    <h3>Add your rating and review </h3>
                    <h4>Your ratings matter</h4>
                    </div>
                    <div className="rateNow d-flex align-items-center btn btn-success">
                        <a href='/'>Rate Now</a>
                    </div>
                </div>
                <div className='bookTickets'>
                    <a href='/' className='btn btn-danger'>Book Tickets</a>
                </div>
            </div>
            <div className="col-md-3">

            </div>
           
        </div>
    </div>
  )
}
